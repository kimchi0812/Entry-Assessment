def update_dictionary(dct, key, value):
    dct[key] = value
    return dct
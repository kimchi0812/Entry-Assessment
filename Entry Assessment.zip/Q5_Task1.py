def check_divisibility(num, divisor):
    if not isinstance(num, (int, float)) or not isinstance(divisor, (int, float)):
        raise ValueError("Both num and divisor must be numeric.")
   
    if divisor == 0:
        raise ValueError("Divisor cannot be zero.")
   
    return num % divisor == 0

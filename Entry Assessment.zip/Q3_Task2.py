def string_reverse(s):
    return s[::-1]
s = "Hello World"
reversed_s = string_reverse(s)
print (reversed_s)
s = "Python"
reversed_s = string_reverse(s)
print (reversed_s)
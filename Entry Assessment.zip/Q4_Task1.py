def string_reverse(s):
    return s[::-1]
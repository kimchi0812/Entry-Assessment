def update_dictionary(dct, key, value):
    # Update the dictionary with the given key and value
    dct[key] = value
    return dct
dct ={}
key="name"
value = "Alice"
updated_dct = update_dictionary(dct,key,value)
print(updated_dct)
dct = {"age":25}
key= "age"
value = 26
updated_dct = update_dictionary(dct, key, value)
print(updated_dct)
from xmlrpc.client import APPLICATION_ERROR


def swap(x, y):
    if not isinstance(x, (int, float)) or not isinstance(y, (int, float)):
        return -1
x = 'Apple'
y=10
result = swap (x,y)
print(result)

x=9
y=17
result = swap (x,y)
print(result)





